# ST VIDEO DOWNLOADER — starter project

Brand: ST VIDEO DOWNLOADER  
Developer credit: Developed by Saymun Khan  
Theme: Premium Green

This is a starter source project containing a responsive web app, a protected admin panel, a Node.js API and an Android WebView shell. It is not a compiled APK and does not include a platform-bypassing TikTok/Instagram downloader. The downloader accepts direct media URLs that you own or are authorized to download; platform-specific integrations must use the platform's official APIs and permissions.

## Requirements
- Node.js 18+
- Android Studio (for Android shell)

## Run backend + web app
1. Open a terminal in `backend/`.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and change `ADMIN_PASSWORD` and `SESSION_SECRET`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

Default admin username is `admin`. Set your own password in `.env` before using this outside local development.

## Included
- `web/index.html`: premium green downloader UI
- `web/admin.html`: admin login/dashboard
- `backend/server.js`: Express API, session login, settings, announcements and basic stats
- `android/`: minimal Android WebView shell starter; configure the deployed URL before building

## Before production
- Deploy behind HTTPS.
- Use a strong unique admin password and session secret.
- Replace JSON storage with a managed database for multi-user production use.
- Add rate limiting, audit logging, backups and proper privacy/terms pages.
- Do not use this app to download content without permission or against a platform's terms.
