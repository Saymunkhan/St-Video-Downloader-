require('dotenv').config();
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
const DATA = path.join(__dirname, 'data.json');
const defaults = { appName: 'ST VIDEO DOWNLOADER', developer: 'Developed by Saymun Khan', announcement: 'Welcome to ST VIDEO DOWNLOADER', downloadsRequested: 0 };
function readData(){ try { return {...defaults, ...JSON.parse(fs.readFileSync(DATA,'utf8'))}; } catch { return {...defaults}; } }
function writeData(d){ fs.writeFileSync(DATA, JSON.stringify(d,null,2)); }
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:'100kb'}));
app.use(session({ name:'st.sid', secret:process.env.SESSION_SECRET || 'development-only-change-me', resave:false, saveUninitialized:false, cookie:{ httpOnly:true, sameSite:'strict', secure:process.env.NODE_ENV === 'production', maxAge: 1000*60*60*4 }}));
app.use(express.static(path.join(__dirname,'..','web')));
const requireAdmin=(req,res,next)=> req.session && req.session.admin ? next() : res.status(401).json({error:'Admin login required'});
app.get('/api/settings',(req,res)=>{ const d=readData(); res.json({appName:d.appName,developer:d.developer,announcement:d.announcement}); });
app.post('/api/admin/login',(req,res)=>{ const {username,password}=req.body||{}; if(username=== (process.env.ADMIN_USERNAME||'admin') && password=== (process.env.ADMIN_PASSWORD||'change-this-password-before-use')) { req.session.admin=true; return res.json({ok:true}); } res.status(401).json({error:'Incorrect username or password'}); });
app.post('/api/admin/logout',requireAdmin,(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/admin/dashboard',requireAdmin,(req,res)=>res.json(readData()));
app.put('/api/admin/settings',requireAdmin,(req,res)=>{ const d=readData(); for(const key of ['appName','developer','announcement']) if(typeof req.body[key]==='string') d[key]=req.body[key].slice(0,180); writeData(d); res.json({ok:true,settings:d}); });
app.post('/api/download/request',(req,res)=>{ const {url}=req.body||{}; let parsed; try { parsed=new URL(url); } catch { return res.status(400).json({error:'Enter a valid direct media URL.'}); } if(!['http:','https:'].includes(parsed.protocol)) return res.status(400).json({error:'Only HTTP/HTTPS URLs are accepted.'}); const d=readData(); d.downloadsRequested++; writeData(d); res.status(501).json({error:'Downloader provider is not configured yet. Use only direct media URLs you own or have permission to download; connect an authorized provider/API to enable downloading.'}); });
app.get('/health',(req,res)=>res.json({ok:true,app:'ST VIDEO DOWNLOADER'}));
app.listen(PORT,()=>console.log(`ST VIDEO DOWNLOADER running at http://localhost:${PORT}`));
